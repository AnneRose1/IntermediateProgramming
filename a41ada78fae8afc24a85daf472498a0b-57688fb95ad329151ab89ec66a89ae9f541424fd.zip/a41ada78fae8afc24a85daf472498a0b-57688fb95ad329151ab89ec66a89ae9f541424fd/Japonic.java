class Japonic extend Language{
  Japonic( String languageName, double speakers){
    super(languageName, "subject-object-verb", "mostly Japan but also in sometimes Taiwan", speakers)
  }
}